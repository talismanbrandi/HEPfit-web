/* 
 * Copyright (C) 2017 HEPfit Collaboration
 *
 *
 * For the licensing terms see doc/COPYING.
 */

#include "GMMatching.h"
#include "GeorgiMachacek.h"

GMMatching::GMMatching(const GeorgiMachacek & GeorgiMachacek_i) :
    StandardModelMatching(GeorgiMachacek_i)
//    myGM(GeorgiMachacek_i)
{}
