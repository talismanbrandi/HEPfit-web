/* 
 * Copyright (C) 2012 HEPfit Collaboration
 *
 *
 * For the licensing terms see doc/COPYING.
 */

#include "BR_Bdnunu.h"
#include "StandardModel.h"

double BR_Bdnunu::computeThValue()
{
    return 0.0;
}


gslpp::complex BR_Bdnunu::BRBdnunu(orders order)
{
    return gslpp::complex(0.0, 0.0);
}

